import Head from "next/head";
import { useState, useRef } from "react";

const EXAMPLES = {
  leasing: `SARAH MITCHELL
Nashville, TN | 615-555-0182 | sarah@email.com

LEASING AGENT — ABC Realty Group | 2018–Present
- Leased 85+ residential and retail properties per year in Greater Nashville
- Negotiated lease terms with landlords and tenants to close deals quickly
- Built relationships with over 200 local property owners and investors
- Managed pipeline of 30+ active listings simultaneously
- Assisted clients with lease renewals and rent negotiations

EDUCATION
Bachelor of Business Administration | Belmont University | 2018`,

  broker: `JAMES OKAFOR
Dallas, TX | 214-555-0310 | james@email.com

BUYER'S AGENT — Keller Williams Premier | 2015–Present
- Closed 40+ transactions annually averaging $450K per sale
- Guided first-time buyers and investors through 100+ home purchases
- Conducted comparative market analysis on 300+ properties
- Managed full transaction cycle from offer to close
- Maintained 98% client satisfaction rating across 5 years
- Mentored team of 4 junior agents

EDUCATION
BS Business | University of Texas at Dallas | 2014
Texas Real Estate License | 2015`,

  property: `DIANA CHEN
Phoenix, AZ | 602-555-0745 | diana@email.com

PROPERTY MANAGER — Sunrise Property Group | 2016–Present
- Managed portfolio of 18 commercial and residential properties (400+ units)
- Reduced vacancy rate from 12% to 4% over 24 months
- Oversaw $2.1M in annual maintenance and capital improvement budgets
- Coordinated with vendors, contractors, and city inspectors for renovations
- Handled lease renewals, rent collection, and tenant relations
- Supervised staff of 6 including maintenance and leasing teams

EDUCATION
Bachelor of Real Estate | Arizona State University | 2016`,
};

export default function Home() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState({ msg: "", type: "" });
  const [copied, setCopied] = useState(false);
  const outputRef = useRef(null);

  function loadExample(key) {
    setInput(EXAMPLES[key]);
    setStatus({ msg: "", type: "" });
  }

  function clearAll() {
    setInput("");
    setOutput("");
    setStatus({ msg: "", type: "" });
    setCopied(false);
  }

  async function copyOutput() {
    await navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  async function transformResume() {
    if (!input.trim()) {
      setStatus({ msg: "Please paste your resume text first.", type: "error" });
      return;
    }
    if (input.trim().length < 100) {
      setStatus({ msg: "Please paste more resume content for a quality transformation.", type: "error" });
      return;
    }

    setLoading(true);
    setOutput("");
    setStatus({ msg: "Analyzing your experience...", type: "" });
    setCopied(false);

    try {
      const res = await fetch("/api/transform", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ resumeText: input }),
      });

      const data = await res.json();

      if (!res.ok) throw new Error(data.error || "Transformation failed.");

      setOutput(data.result);
      setStatus({ msg: "✓ Transformation complete", type: "success" });
    } catch (err) {
      setStatus({ msg: err.message || "Something went wrong. Try again.", type: "error" });
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <Head>
        <title>ResetResume — Chandler Johnson Coaching</title>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap"
          rel="stylesheet"
        />
      </Head>

      <style jsx global>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        :root {
          --navy: #0b1f3a;
          --gold: #c9973a;
          --gold-light: #e8c07a;
          --cream: #f7f3ec;
          --white: #ffffff;
          --gray-400: #9a9182;
          --green: #2e7d55;
          --red: #c0392b;
          --radius: 6px;
        }
        body { font-family: 'DM Sans', sans-serif; background: var(--navy); color: var(--cream); min-height: 100vh; }
        @keyframes shimmer { 0%,100%{opacity:1} 50%{opacity:0.35} }
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
      `}</style>

      {/* HEADER */}
      <header style={{
        background: "var(--navy)",
        borderBottom: "2px solid var(--gold)",
        padding: "18px 40px",
        display: "flex",
        alignItems: "center",
        gap: 16,
      }}>
        <div style={{
          width: 42, height: 42,
          background: "var(--gold)",
          borderRadius: 4,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontFamily: "'Bebas Neue', sans-serif",
          fontSize: 22, color: "var(--navy)", letterSpacing: 1,
          flexShrink: 0,
        }}>CJ</div>
        <div style={{ display: "flex", flexDirection: "column", lineHeight: 1.1 }}>
          <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: 20, letterSpacing: 2, color: "var(--cream)" }}>
            Chandler Johnson Coaching
          </span>
          <span style={{ fontSize: 11, color: "var(--gold)", letterSpacing: 1.5, textTransform: "uppercase", fontWeight: 600 }}>
            Real Estate Reset™
          </span>
        </div>
        <div style={{
          marginLeft: "auto",
          background: "rgba(201,151,58,0.15)",
          border: "1px solid var(--gold)",
          color: "var(--gold)",
          fontSize: 11, fontWeight: 700,
          letterSpacing: 1.5, textTransform: "uppercase",
          padding: "5px 14px", borderRadius: 20,
        }}>ResetResume</div>
      </header>

      {/* HERO */}
      <div style={{
        textAlign: "center",
        padding: "60px 24px 48px",
        background: "linear-gradient(180deg, rgba(201,151,58,0.06) 0%, transparent 100%)",
      }}>
        <div style={{ fontSize: 11, letterSpacing: 3, textTransform: "uppercase", color: "var(--gold)", fontWeight: 600, marginBottom: 16 }}>
          Corporate Real Estate Pivot™
        </div>
        <h1 style={{
          fontFamily: "'DM Serif Display', serif",
          fontSize: "clamp(32px, 5vw, 54px)",
          lineHeight: 1.1,
          color: "var(--white)",
          maxWidth: 680,
          margin: "0 auto 20px",
        }}>
          Transform Your Resume Into a{" "}
          <em style={{ fontStyle: "italic", color: "var(--gold-light)" }}>Corporate RE Powerhouse</em>
        </h1>
        <p style={{ fontSize: 16, color: "var(--gray-400)", maxWidth: 540, margin: "0 auto", lineHeight: 1.7, fontWeight: 300 }}>
          Paste your current residential resume. Watch it rebuild in the language of site selection, portfolio strategy, and lease negotiation — the language that gets you hired.
        </p>
      </div>

      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 24px 80px" }}>

        {/* STATS */}
        <div style={{
          display: "flex", gap: 32, padding: "28px 0",
          borderTop: "1px solid rgba(201,151,58,0.12)",
          borderBottom: "1px solid rgba(201,151,58,0.12)",
          marginBottom: 32, flexWrap: "wrap",
        }}>
          {[["20+","Years Corporate RE"],["300+","Deals Closed"],["$500M+","Revenue Impact"],["3","Fortune 500 Brands"]].map(([val, lbl]) => (
            <div key={lbl} style={{ display: "flex", flexDirection: "column", gap: 4 }}>
              <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: 28, color: "var(--gold)", letterSpacing: 1 }}>{val}</span>
              <span style={{ fontSize: 11, color: "var(--gray-400)", textTransform: "uppercase", letterSpacing: 1.5, fontWeight: 600 }}>{lbl}</span>
            </div>
          ))}
        </div>

        {/* EXAMPLES */}
        <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 16, flexWrap: "wrap" }}>
          <span style={{ fontSize: 11, color: "var(--gray-400)", textTransform: "uppercase", letterSpacing: 1.5, fontWeight: 600 }}>Try an example:</span>
          {[["leasing","Leasing Agent"],["broker","Buyer's Broker"],["property","Property Manager"]].map(([key, label]) => (
            <button key={key} onClick={() => loadExample(key)} style={{
              background: "rgba(201,151,58,0.12)",
              border: "1px solid rgba(201,151,58,0.3)",
              color: "var(--gold-light)",
              borderRadius: 20, fontSize: 12, padding: "4px 14px",
              cursor: "pointer",
            }}>{label}</button>
          ))}
        </div>

        {/* CONTROLS */}
        <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 12, flexWrap: "wrap" }}>
          <button
            onClick={transformResume}
            disabled={loading}
            style={{
              background: loading ? "rgba(201,151,58,0.5)" : "var(--gold)",
              color: "var(--navy)",
              border: "none", borderRadius: "var(--radius)",
              padding: "13px 32px",
              fontFamily: "'DM Sans', sans-serif",
              fontSize: 14, fontWeight: 700, letterSpacing: 0.5,
              cursor: loading ? "not-allowed" : "pointer",
              display: "flex", alignItems: "center", gap: 8,
              animation: loading ? "shimmer 1.4s infinite" : "none",
            }}
          >
            <span>{loading ? "⏳" : "✦"}</span>
            {loading ? "Transforming..." : "Reset My Resume"}
          </button>

          <button onClick={clearAll} style={{
            background: "transparent", color: "var(--gray-400)",
            border: "1px solid rgba(154,145,130,0.3)", borderRadius: "var(--radius)",
            padding: "12px 20px",
            fontFamily: "'DM Sans', sans-serif", fontSize: 13,
            cursor: "pointer", display: "flex", alignItems: "center", gap: 6,
          }}>✕ Clear</button>

          <span style={{
            fontSize: 12, fontWeight: 500, letterSpacing: 0.5, minHeight: 18,
            color: status.type === "error" ? "var(--red)" : status.type === "success" ? "var(--green)" : "var(--gold)",
          }}>{status.msg}</span>

          {output && (
            <button onClick={copyOutput} style={{
              marginLeft: "auto",
              background: "transparent", color: "var(--gray-400)",
              border: "1px solid rgba(154,145,130,0.3)", borderRadius: "var(--radius)",
              padding: "12px 20px",
              fontFamily: "'DM Sans', sans-serif", fontSize: 13,
              cursor: "pointer", display: "flex", alignItems: "center", gap: 6,
            }}>
              {copied ? "✓ Copied!" : "⎘ Copy Result"}
            </button>
          )}
        </div>

        {/* PROGRESS BAR */}
        <div style={{ height: 3, background: "rgba(201,151,58,0.15)", borderRadius: 2, marginBottom: 20, overflow: "hidden" }}>
          <div style={{
            height: "100%",
            width: loading ? "100%" : output ? "100%" : "0%",
            background: "var(--gold)", borderRadius: 2,
            transition: "width 0.4s ease",
            animation: loading ? "shimmer 1.4s infinite" : "none",
          }} />
        </div>

        {/* COLUMNS */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(400px, 1fr))",
          gap: 24,
        }}>
          {/* INPUT PANEL */}
          <div style={{
            background: "rgba(255,255,255,0.04)",
            border: "1px solid rgba(201,151,58,0.2)",
            borderRadius: 10, display: "flex", flexDirection: "column", overflow: "hidden",
          }}>
            <div style={{
              padding: "16px 20px 14px",
              borderBottom: "1px solid rgba(201,151,58,0.15)",
              display: "flex", alignItems: "center", justifyContent: "space-between",
            }}>
              <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", color: "var(--gold)" }}>
                Your Current Resume
              </span>
              <span style={{ fontSize: 11, color: "var(--gray-400)" }}>Paste plain text</span>
            </div>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={"Paste your residential or commercial brokerage resume here...\n\nInclude your experience, bullet points, and any metrics you have. The more detail, the better the transformation."}
              style={{
                flex: 1, width: "100%", minHeight: 460,
                background: "transparent", border: "none", outline: "none",
                resize: "none",
                fontFamily: "'DM Sans', sans-serif", fontSize: 13.5,
                lineHeight: 1.65, color: "var(--cream)",
                padding: 20, caretColor: "var(--gold)",
              }}
            />
          </div>

          {/* OUTPUT PANEL */}
          <div style={{
            background: "rgba(255,255,255,0.04)",
            border: "1px solid rgba(201,151,58,0.2)",
            borderRadius: 10, display: "flex", flexDirection: "column", overflow: "hidden",
          }}>
            <div style={{
              padding: "16px 20px 14px",
              borderBottom: "1px solid rgba(201,151,58,0.15)",
              display: "flex", alignItems: "center", justifyContent: "space-between",
            }}>
              <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: 2, textTransform: "uppercase", color: "var(--gold)" }}>
                Corporate RE Version
              </span>
              <span style={{ fontSize: 11, color: "var(--gray-400)" }}>AI Rewritten Copy</span>
            </div>
            <div ref={outputRef} style={{
              flex: 1, minHeight: 460, padding: 20,
              fontSize: 13.5, lineHeight: 1.75,
              color: "var(--cream)", whiteSpace: "pre-wrap",
              overflowY: "auto",
              display: "flex",
              alignItems: output ? "flex-start" : "center",
              justifyContent: output ? "flex-start" : "center",
            }}>
              {output ? (
                <span>{output}</span>
              ) : (
                <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12, opacity: 0.4 }}>
                  <span style={{ fontSize: 36 }}>🏢</span>
                  <p style={{ fontSize: 13, color: "var(--gray-400)", textAlign: "center" }}>
                    Your corporate-ready resume will appear here after transformation.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* FOOTER */}
      <footer style={{
        textAlign: "center", padding: 24,
        fontSize: 12, color: "rgba(154,145,130,0.5)",
        borderTop: "1px solid rgba(201,151,58,0.1)",
        letterSpacing: 0.5,
      }}>
        Built for <strong>Chandler Johnson Coaching</strong> &bull; Corporate Real Estate Pivot™ &bull; Powered by{" "}
        <a href="https://anthropic.com" target="_blank" rel="noopener noreferrer" style={{ color: "var(--gold)", textDecoration: "none" }}>
          Claude AI
        </a>
      </footer>
    </>
  );
}
