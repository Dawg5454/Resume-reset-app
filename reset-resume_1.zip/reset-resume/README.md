# ResetResume — Chandler Johnson Coaching

Corporate Real Estate Pivot™ Resume Transformer

## Deploy to Vercel (replace existing app)

### Option A — Replace via GitHub
1. Copy `pages/index.js`, `pages/api/transform.js`, `pages/\_app.js`, `styles/globals.css`, and `package.json` into your existing GitHub repo
2. Push to main — Vercel auto-deploys
3. In Vercel dashboard → **Settings → Environment Variables** → add:
   ```
   ANTHROPIC_API_KEY = your_key_here
   ```
4. Redeploy (or it auto-redeploys on next push)

### Option B — New Vercel project
1. Upload this folder to a new GitHub repo
2. Connect repo to Vercel
3. Add `ANTHROPIC_API_KEY` in Vercel → Settings → Environment Variables
4. Deploy

## How it works
- The browser calls `/api/transform` (your own Vercel serverless function)
- That function calls Anthropic server-side with your API key (never exposed to the browser)
- No CORS errors. No API key leaks.

## Local dev
```bash
npm install
# create .env.local with: ANTHROPIC_API_KEY=sk-...
npm run dev
```
